
function myFunction1(){
    var a = document.getElementById("content1");
    if(a.style.display=="none"){
        a.style.display="block";
        }else{
            a.style.display="none";
    }
}


function myFunction2(){
  var a = document.getElementById("content2");
  if(a.style.display=="none"){
      a.style.display="block";
      }else{
          a.style.display="none";
  }
}


function myFunction3(){
  var a = document.getElementById("content3");
  if(a.style.display=="none"){
      a.style.display="block";
      }else{
          a.style.display="none";
  }
}


function myFunction4(){
  var a = document.getElementById("content4");
  if(a.style.display=="none"){
      a.style.display="block";
      }else{
          a.style.display="none";
  }
}


function myFunction5(){
  var a = document.getElementById("content5");
  if(a.style.display=="none"){
      a.style.display="block";
      }else{
          a.style.display="none";
  }
}


function myFunction6(){
  var a = document.getElementById("content6");
  if(a.style.display=="none"){
      a.style.display="block";
      }else{
          a.style.display="none";
  }
}

